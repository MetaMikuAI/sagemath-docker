#!/bin/bash

../../msolve -f simple_char65521.ms -o simple_char65521.res
