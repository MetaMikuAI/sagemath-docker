#!/bin/bash

../../msolve -P 2 -f param_char0.ms -o param_char0.res
