#!/bin/bash

../../msolve -p 256 -f reals_dim0.ms -o reals_dim0_prec256.res
