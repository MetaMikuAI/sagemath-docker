#!/bin/bash

../../msolve -S -g 2 -f saturate_char1073741827.ms -o saturate_char1073741827.res
