#!/bin/bash

../../msolve -f hypersurface_char0.ms -o hypersurface_char0.res
