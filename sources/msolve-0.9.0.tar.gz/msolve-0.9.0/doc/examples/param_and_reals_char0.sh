#!/bin/bash

../../msolve -P 1 -f param_char0.ms -o param_and_reals_char0.res
