#!/bin/bash

../../msolve -g 1 -f grevlex_char1073741827.ms -o grevlex_lm_char1073741827.res
