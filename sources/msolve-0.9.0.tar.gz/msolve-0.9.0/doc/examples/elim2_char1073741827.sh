#!/bin/bash

../../msolve -e 2 -g 2 -f elim_char1073741827.ms -o elim2_char1073741827.res
