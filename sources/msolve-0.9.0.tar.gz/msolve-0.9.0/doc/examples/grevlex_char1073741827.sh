#!/bin/bash

../../msolve -g 2 -f grevlex_char1073741827.ms -o grevlex_char1073741827.res
