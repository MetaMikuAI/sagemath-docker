#!/bin/bash

file=radical_shape-31

source test/diff/diff_source.sh
