#!/bin/bash

file=nonradical_radicalshape-31

source test/diff/diff_source.sh
