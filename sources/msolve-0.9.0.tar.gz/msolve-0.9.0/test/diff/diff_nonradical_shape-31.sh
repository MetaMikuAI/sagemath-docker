#!/bin/bash

file=nonradical_shape-31

source test/diff/diff_source.sh
