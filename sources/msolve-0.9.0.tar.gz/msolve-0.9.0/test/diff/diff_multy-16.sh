#!/bin/bash

file=multy-16

source test/diff/diff_source.sh
