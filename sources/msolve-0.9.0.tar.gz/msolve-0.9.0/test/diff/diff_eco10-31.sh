#!/bin/bash

file=eco10-31

source test/diff/diff_source.sh
