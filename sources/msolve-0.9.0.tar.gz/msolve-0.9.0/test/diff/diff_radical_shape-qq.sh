#!/bin/bash

file=radical_shape-qq

source test/diff/diff_source.sh
