#!/bin/bash

file=cp_d_3_n_4_p_2

source test/diff/diff_source.sh
