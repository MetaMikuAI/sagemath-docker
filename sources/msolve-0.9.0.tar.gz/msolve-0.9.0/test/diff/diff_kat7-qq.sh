#!/bin/bash

file=kat7-qq

source test/diff/diff_source.sh
