#!/bin/bash

../../msolve -P 2 -f param_simple.ms -o param_simple.res
