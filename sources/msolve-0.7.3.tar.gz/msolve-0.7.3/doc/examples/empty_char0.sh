#!/bin/bash

../../msolve -f empty_char0.ms -o empty_char0.res
