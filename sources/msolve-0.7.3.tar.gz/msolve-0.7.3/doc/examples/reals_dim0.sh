#!/bin/bash

../../msolve -f reals_dim0.ms -o reals_dim0.res
