#!/bin/bash

../../msolve -P 2 -f param_char65521.ms -o param_char65521.res
