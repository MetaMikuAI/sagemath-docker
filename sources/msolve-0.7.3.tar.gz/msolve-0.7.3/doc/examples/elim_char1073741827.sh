#!/bin/bash

../../msolve -e 1 -g 2 -f elim_char1073741827.ms -o elim_char1073741827.res
