#!/bin/bash

../../msolve -f simple_char0.ms -o simple_char0.res
