#!/bin/bash

file=xy-qq

source test/diff/diff_source.sh
