#!/bin/bash

file=one-16

source test/diff/diff_source.sh


