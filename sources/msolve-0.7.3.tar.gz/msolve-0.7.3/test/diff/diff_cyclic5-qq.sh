#!/bin/bash

file=cyclic5-qq

source test/diff/diff_source.sh

source test/diff/diff_source-groebner.sh
