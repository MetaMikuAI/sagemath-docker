#!/bin/bash

file=linear-qq

source test/diff/diff_source.sh
