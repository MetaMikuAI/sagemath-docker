#!/bin/bash

file=test-lifting2

source test/diff/diff_source.sh

