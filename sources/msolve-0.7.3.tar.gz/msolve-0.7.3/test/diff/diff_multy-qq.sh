#!/bin/bash

file=multy-qq

source test/diff/diff_source.sh
