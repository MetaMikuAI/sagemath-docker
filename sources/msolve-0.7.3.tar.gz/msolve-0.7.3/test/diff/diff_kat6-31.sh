#!/bin/bash

file=kat6-31

source test/diff/diff_source.sh
