#!/bin/bash

file=multy-31

source test/diff/diff_source.sh
