#include <string>

namespace flatter {

void initialize();
void initialize(const std::string& logfile_name);

void finalize();

}